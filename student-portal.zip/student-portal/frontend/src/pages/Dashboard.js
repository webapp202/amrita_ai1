import React from 'react';
import '../styles/Dashboard.css';

function Dashboard() {
  return (
    <div className="dashboard-container">
      <h1>Welcome to the Student Portal</h1>
      <div className="portal-links">
        <a href="https://cms.cb.amrita.edu/login" target="_blank" rel="noopener noreferrer">CMS</a>
        <a href="https://my.amrita.edu" target="_blank" rel="noopener noreferrer">myAmrita</a>
        <a href="https://aumscb.amrita.edu/cas/login?service=https%3A%2F%2Faumscb.amrita.edu%2Faums%2FJsp%2FCore_Common%2Findex.jsp" target="_blank" rel="noopener noreferrer">AUMS</a>
        <a href="https://intranet.cb.amrita.edu" target="_blank" rel="noopener noreferrer">Intranet CBE</a>
      </div>
    </div>
  );
}

export default Dashboard;
