# Student Portal

## Description
A consolidated student portal for easy access to multiple student portals.

## Features
- Authentication with JWT
- Separate routes for each student portal
- Responsive design using React and CSS

## Project Structure
