const express = require('express');
const router = express.Router();

// Implement routes for AUMS portal

module.exports = router;
