const express = require('express');
const router = express.Router();

// Implement routes for CMS portal

module.exports = router;
