const express = require('express');
const router = express.Router();

// Implement routes for myAmrita portal

module.exports = router;
