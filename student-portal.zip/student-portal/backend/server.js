const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const authRoutes = require('./routes/auth');
const cmsRoutes = require('./routes/cms');
const myAmritaRoutes = require('./routes/myAmrita');
const aumsRoutes = require('./routes/aums');
const intranetRoutes = require('./routes/intranet');
const errorHandler = require('./middlewares/errorHandler');
const verifyToken = require('./middlewares/verifyToken');

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.use('/auth', authRoutes);
app.use('/cms', verifyToken, cmsRoutes);
app.use('/myAmrita', verifyToken, myAmritaRoutes);
app.use('/aums', verifyToken, aumsRoutes);
app.use('/intranet', verifyToken, intranetRoutes);

app.use(errorHandler);

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
